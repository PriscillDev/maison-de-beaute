import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

const Contact = () => {
  const { addSubmission } = useFormContext();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSubmission({
      type: 'contact',
      data: formData
    });
    alert('Message sent successfully! We will get back to you soon.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      subject: '',
      message: ''
    });
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Contact Us</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Get in touch with us for appointments, questions, or feedback. We're here to help!
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Address</h3>
              <p className="text-gray-600">
                123 Luxury Avenue<br />
                Beauty District<br />
                City, State 12345
              </p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Phone</h3>
              <p className="text-gray-600">
                Main: (555) 123-4567<br />
                WhatsApp: (555) 765-4321
              </p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Mail className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Email</h3>
              <p className="text-gray-600">
                info@luxespa.com<br />
                bookings@luxespa.com
              </p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Hours</h3>
              <p className="text-gray-600">
                Mon-Sat: 9:00 AM - 7:00 PM<br />
                Sunday: Closed
              </p>
            </div>
          </div>

          {/* Contact Form and Map */}
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 className="text-3xl font-bold text-deep-teal mb-6">Send us a Message</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                </div>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Subject
                    </label>
                    <select
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    >
                      <option value="">Select subject</option>
                      <option value="booking">Booking Inquiry</option>
                      <option value="services">Services Information</option>
                      <option value="complaint">Complaint</option>
                      <option value="feedback">Feedback</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Message *
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    placeholder="Tell us how we can help you..."
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-rose-gold hover:bg-rose-gold/90 text-white py-3 px-6 rounded-lg font-semibold transition-colors duration-300 flex items-center justify-center"
                >
                  <Send className="h-5 w-5 mr-2" />
                  Send Message
                </button>
              </form>
            </div>

            {/* Map */}
            <div>
              <h2 className="text-3xl font-bold text-deep-teal mb-6">Find Us</h2>
              <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Interactive map would be embedded here</p>
                  <p className="text-gray-500 text-sm mt-2">
                    Google Maps integration showing our location
                  </p>
                </div>
              </div>
              <div className="mt-6 p-6 bg-gray-50 rounded-lg">
                <h3 className="text-xl font-semibold text-deep-teal mb-3">Directions</h3>
                <p className="text-gray-600 mb-2">
                  <strong>By Car:</strong> Free parking available in our private lot
                </p>
                <p className="text-gray-600 mb-2">
                  <strong>By Public Transit:</strong> Metro Line 2, Beauty District Station
                </p>
                <p className="text-gray-600">
                  <strong>Walking:</strong> 2 minutes from Main Street shopping center
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 text-lg">Quick answers to common questions</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">How do I book an appointment?</h3>
                <p className="text-gray-600">You can book online through our website, call us, or visit us in person. We recommend booking in advance for your preferred time slot.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">What is your cancellation policy?</h3>
                <p className="text-gray-600">We require 24 hours notice for cancellations. Cancellations made less than 24 hours in advance may be subject to a fee.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">Do you offer group bookings?</h3>
                <p className="text-gray-600">Yes! We offer special group packages for parties, events, and spa days. Contact us for group rates and availability.</p>
              </div>
            </div>
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">What safety measures do you have?</h3>
                <p className="text-gray-600">We follow strict hygiene protocols, use disposable tools when possible, and maintain a clean, sanitized environment for all our services.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">Do you accept walk-ins?</h3>
                <p className="text-gray-600">While we accept walk-ins based on availability, we highly recommend booking an appointment to ensure you get your preferred service and time.</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <h3 className="text-lg font-semibold text-deep-teal mb-2">What payment methods do you accept?</h3>
                <p className="text-gray-600">We accept cash, all major credit cards, and digital payments. Gift cards are also available for purchase.</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;