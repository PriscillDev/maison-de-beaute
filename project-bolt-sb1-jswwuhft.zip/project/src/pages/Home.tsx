import React from 'react';
import { Link } from 'react-router-dom';
import { Star, Calendar, Award, Users, ArrowRight } from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: <Star className="h-8 w-8 text-rose-gold" />,
      title: "Premium Quality",
      description: "We use only the finest products and latest techniques"
    },
    {
      icon: <Calendar className="h-8 w-8 text-rose-gold" />,
      title: "Easy Booking",
      description: "Book your appointment online 24/7 with our simple system"
    },
    {
      icon: <Award className="h-8 w-8 text-rose-gold" />,
      title: "Certified Professionals",
      description: "Our team consists of licensed and experienced specialists"
    },
    {
      icon: <Users className="h-8 w-8 text-rose-gold" />,
      title: "Satisfied Clients",
      description: "Over 5,000 happy customers and counting"
    }
  ];

  const services = [
    {
      name: "Classic Manicure",
      price: "From $35",
      image: "https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Spa Pedicure",
      price: "From $50",
      image: "https://images.pexels.com/photos/3997992/pexels-photo-3997992.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Gel Extensions",
      price: "From $65",
      image: "https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&w=400"
    },
    {
      name: "Facial Treatment",
      price: "From $80",
      image: "https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=400"
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="absolute inset-0 bg-black/40 z-10"></div>
        <video
          className="absolute inset-0 w-full h-full object-cover"
          autoPlay
          muted
          loop
          playsInline
        >
          <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4" />
        </video>
        
        <div className="relative z-20 text-center text-white px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Experience Luxury
            <br />
            <span className="text-rose-gold">Beauty & Wellness</span>
          </h1>
          <p className="text-xl sm:text-2xl mb-8 max-w-3xl mx-auto">
            Indulge in our premium nail care, beauty treatments, and spa services designed to make you shine with confidence and elegance.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/booking"
              className="bg-gradient-to-r from-rose-gold to-gold hover:from-rose-gold/90 hover:to-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              Book Your Appointment
            </Link>
            <Link
              to="/services"
              className="border-2 border-white text-white hover:bg-white hover:text-deep-teal px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300"
            >
              View Our Services
            </Link>
          </div>
        </div>
      </section>

      {/* Beauty Showcase Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Nail Art & Spa Excellence</h2>
            <p className="text-gray-600 text-lg">Discover the artistry and relaxation that defines Maison de Beauté</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Nail Art Showcase */}
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-rose-gold/10 to-deep-teal/10 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-deep-teal mb-4">💅 Exquisite Nail Artistry</h3>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <img
                    src="https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=300"
                    alt="Nail art design"
                    className="rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                  />
                  <img
                    src="https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&w=300"
                    alt="Gel extensions"
                    className="rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                  />
                </div>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center"><span className="w-2 h-2 bg-rose-gold rounded-full mr-3"></span>Custom nail art designs</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-rose-gold rounded-full mr-3"></span>Gel & acrylic extensions</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-rose-gold rounded-full mr-3"></span>French manicures & classics</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-rose-gold rounded-full mr-3"></span>Nail health treatments</li>
                </ul>
              </div>
            </div>
            
            {/* Spa Showcase */}
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-deep-teal/10 to-rose-gold/10 rounded-2xl p-8">
                <h3 className="text-2xl font-bold text-deep-teal mb-4">🧖‍♀️ Luxurious Spa Treatments</h3>
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <img
                    src="https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=300"
                    alt="Facial treatment"
                    className="rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                  />
                  <img
                    src="https://images.pexels.com/photos/3997995/pexels-photo-3997995.jpeg?auto=compress&cs=tinysrgb&w=300"
                    alt="Massage therapy"
                    className="rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300"
                  />
                </div>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center"><span className="w-2 h-2 bg-deep-teal rounded-full mr-3"></span>Rejuvenating facials</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-deep-teal rounded-full mr-3"></span>Therapeutic massages</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-deep-teal rounded-full mr-3"></span>Spa pedicures</li>
                  <li className="flex items-center"><span className="w-2 h-2 bg-deep-teal rounded-full mr-3"></span>Wellness packages</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Special Offers */}
      <section className="py-16 bg-rose-gold/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Special Offers</h2>
            <p className="text-gray-600 text-lg">Don't miss our exceptional offers and promotions</p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden transform hover:scale-105 transition-transform duration-300">
              <div className="bg-gradient-to-r from-rose-gold to-gold p-6">
                <h3 className="text-2xl font-bold text-white mb-2">New Client Offer</h3>
                <p className="text-white/90">First visit discount</p>
              </div>
              <div className="p-6">
                <div className="text-4xl font-bold text-deep-teal mb-4">20% OFF</div>
                <p className="text-gray-600 mb-4">Get 20% off your first service. Valid for new clients only.</p>
                <Link
                  to="/booking"
                  className="inline-flex items-center text-rose-gold hover:text-rose-gold/80 font-semibold"
                >
                  Book Now <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>

            <div className="bg-white rounded-2xl shadow-xl overflow-hidden transform hover:scale-105 transition-transform duration-300">
              <div className="bg-gradient-to-r from-deep-teal to-rose-gold p-6">
                <h3 className="text-2xl font-bold text-white mb-2">Complete Spa Package</h3>
                <p className="text-white/90">Full wellness experience</p>
              </div>
              <div className="p-6">
                <div className="text-4xl font-bold text-deep-teal mb-4">$150</div>
                <p className="text-gray-600 mb-4">Manicure + Pedicure + Facial package. Save $30 when booking all three services together.</p>
                <Link
                  to="/booking"
                  className="inline-flex items-center text-rose-gold hover:text-rose-gold/80 font-semibold"
                >
                  Book Package <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Services */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Featured Services</h2>
            <p className="text-gray-600 text-lg">Discover our most popular treatments</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="group cursor-pointer">
                <div className="relative overflow-hidden rounded-2xl shadow-lg mb-4">
                  <img
                    src={service.image}
                    alt={service.name}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-semibold">{service.name}</h3>
                    <p className="text-rose-gold font-bold">{service.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <Link
              to="/services"
              className="bg-gradient-to-r from-deep-teal to-rose-gold hover:from-deep-teal/90 hover:to-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              View All Our Services
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Why Choose Maison de Beauté?</h2>
            <p className="text-gray-600 text-lg">Discover the difference with our premium service</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center group">
                <div className="bg-white rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-semibold text-deep-teal mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to Be Pampered?</h2>
          <p className="text-xl text-white/90 mb-8">Book your appointment today and experience luxury like never before</p>
          <Link
            to="/booking"
            className="bg-white text-deep-teal hover:bg-gray-100 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg"
          >
            Book Your Appointment
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;