import React from 'react';
import { Calendar, User, ArrowRight, Tag } from 'lucide-react';

const Blog = () => {
  const blogPosts = [
    {
      title: "Summer Nail Trends 2024: What's Hot This Season",
      excerpt: "Discover the latest nail trends for summer 2024, from vibrant colors to minimalist designs that will make your nails the talk of the season.",
      author: "Sarah Johnson",
      date: "June 15, 2024",
      category: "Trends",
      image: "https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "5 min read"
    },
    {
      title: "The Ultimate Guide to Nail Care: Tips from Our Experts",
      excerpt: "Learn professional nail care tips and techniques that will keep your nails healthy, strong, and beautiful between salon visits.",
      author: "Maria Rodriguez",
      date: "June 10, 2024",
      category: "Tips",
      image: "https://images.pexels.com/photos/3997992/pexels-photo-3997992.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "8 min read"
    },
    {
      title: "Facial Treatments: Which One is Right for Your Skin Type?",
      excerpt: "Explore different facial treatments and learn how to choose the perfect one for your specific skin type and concerns.",
      author: "Jessica Williams",
      date: "June 5, 2024",
      category: "Skincare",
      image: "https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "6 min read"
    },
    {
      title: "Gel vs. Acrylic: Which Nail Enhancement is Best for You?",
      excerpt: "Compare gel and acrylic nail enhancements to help you decide which option will give you the best results for your lifestyle.",
      author: "Maria Rodriguez",
      date: "May 28, 2024",
      category: "Education",
      image: "https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "7 min read"
    },
    {
      title: "Preparing for Your Wedding: The Ultimate Bridal Beauty Timeline",
      excerpt: "A comprehensive guide to planning your bridal beauty treatments, from six months before to your wedding day.",
      author: "Sarah Johnson",
      date: "May 20, 2024",
      category: "Bridal",
      image: "https://images.pexels.com/photos/3997995/pexels-photo-3997995.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "10 min read"
    },
    {
      title: "The Benefits of Regular Massage Therapy for Your Health",
      excerpt: "Discover how regular massage therapy can improve your physical and mental well-being, plus tips for getting the most from your sessions.",
      author: "Emma Chen",
      date: "May 15, 2024",
      category: "Wellness",
      image: "https://images.pexels.com/photos/3997996/pexels-photo-3997996.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "9 min read"
    },
    {
      title: "Seasonal Skincare: Adapting Your Routine for Different Weather",
      excerpt: "Learn how to adjust your skincare routine throughout the year to maintain healthy, glowing skin in any season.",
      author: "Jessica Williams",
      date: "May 8, 2024",
      category: "Skincare",
      image: "https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "8 min read"
    },
    {
      title: "Nail Art Inspiration: Creative Designs for Every Occasion",
      excerpt: "Get inspired with creative nail art ideas perfect for holidays, special events, or just adding some fun to your everyday look.",
      author: "Maria Rodriguez",
      date: "April 30, 2024",
      category: "Trends",
      image: "https://images.pexels.com/photos/3762801/pexels-photo-3762801.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "6 min read"
    },
    {
      title: "Self-Care Sunday: Creating Your Perfect At-Home Spa Experience",
      excerpt: "Transform your home into a relaxing spa with these simple tips and techniques for the ultimate self-care experience.",
      author: "Sarah Johnson",
      date: "April 25, 2024",
      category: "Self-Care",
      image: "https://images.pexels.com/photos/3762802/pexels-photo-3762802.jpeg?auto=compress&cs=tinysrgb&w=600",
      readTime: "7 min read"
    }
  ];

  const categories = ["All", "Trends", "Tips", "Skincare", "Education", "Bridal", "Wellness", "Self-Care"];
  const [selectedCategory, setSelectedCategory] = React.useState("All");

  const filteredPosts = selectedCategory === "All" 
    ? blogPosts 
    : blogPosts.filter(post => post.category === selectedCategory);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Beauty & Wellness Blog</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Expert tips, trends, and insights from our professional beauty team to help you look and feel your best.
          </p>
        </div>
      </section>

      {/* Featured Post */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-rose-gold/10 to-deep-teal/10 rounded-2xl overflow-hidden">
            <div className="grid lg:grid-cols-2 gap-8 items-center">
              <div className="p-8 lg:p-12">
                <div className="flex items-center space-x-4 mb-4">
                  <span className="bg-rose-gold text-white px-3 py-1 rounded-full text-sm font-medium">
                    Featured
                  </span>
                  <span className="bg-deep-teal text-white px-3 py-1 rounded-full text-sm font-medium">
                    {blogPosts[0].category}
                  </span>
                </div>
                <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">
                  {blogPosts[0].title}
                </h2>
                <p className="text-gray-600 text-lg mb-6">
                  {blogPosts[0].excerpt}
                </p>
                <div className="flex items-center space-x-6 text-sm text-gray-500 mb-6">
                  <div className="flex items-center">
                    <User className="h-4 w-4 mr-2" />
                    {blogPosts[0].author}
                  </div>
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2" />
                    {blogPosts[0].date}
                  </div>
                </div>
                <button className="bg-rose-gold hover:bg-rose-gold/90 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-300 inline-flex items-center">
                  Read More <ArrowRight className="ml-2 h-4 w-4" />
                </button>
              </div>
              <div className="lg:p-8">
                <img
                  src={blogPosts[0].image}
                  alt={blogPosts[0].title}
                  className="w-full h-80 object-cover rounded-lg"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  selectedCategory === category
                    ? 'bg-rose-gold text-white shadow-lg'
                    : 'bg-white text-deep-teal hover:bg-rose-gold/10 border border-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Posts Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.slice(1).map((post, index) => (
              <article key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300">
                <div className="relative overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-48 object-cover hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-rose-gold text-white px-3 py-1 rounded-full text-sm font-medium">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-deep-teal mb-3 hover:text-rose-gold transition-colors duration-300 cursor-pointer">
                    {post.title}
                  </h3>
                  <p className="text-gray-600 mb-4 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center">
                        <User className="h-4 w-4 mr-1" />
                        {post.author}
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {post.date}
                      </div>
                    </div>
                    <span className="text-rose-gold font-medium">{post.readTime}</span>
                  </div>
                  <button className="text-rose-gold hover:text-rose-gold/80 font-semibold inline-flex items-center">
                    Read More <ArrowRight className="ml-2 h-4 w-4" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter Signup */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Stay Updated</h2>
          <p className="text-gray-600 text-lg mb-8">
            Subscribe to our newsletter for the latest beauty tips, trends, and exclusive offers.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
            />
            <button className="bg-rose-gold hover:bg-rose-gold/90 text-white px-6 py-3 rounded-lg font-semibold transition-colors duration-300 whitespace-nowrap">
              Subscribe
            </button>
          </div>
        </div>
      </section>

      {/* Popular Topics */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Popular Topics</h2>
            <p className="text-gray-600 text-lg">Explore our most popular beauty and wellness topics</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
              <Tag className="h-8 w-8 text-rose-gold mx-auto mb-3" />
              <h3 className="font-semibold text-deep-teal mb-2">Nail Care</h3>
              <p className="text-gray-600 text-sm">Tips and techniques for healthy nails</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
              <Tag className="h-8 w-8 text-rose-gold mx-auto mb-3" />
              <h3 className="font-semibold text-deep-teal mb-2">Skincare</h3>
              <p className="text-gray-600 text-sm">Achieve radiant, healthy skin</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
              <Tag className="h-8 w-8 text-rose-gold mx-auto mb-3" />
              <h3 className="font-semibold text-deep-teal mb-2">Trends</h3>
              <p className="text-gray-600 text-sm">Latest beauty and fashion trends</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md text-center hover:shadow-lg transition-shadow duration-300">
              <Tag className="h-8 w-8 text-rose-gold mx-auto mb-3" />
              <h3 className="font-semibold text-deep-teal mb-2">Wellness</h3>
              <p className="text-gray-600 text-sm">Holistic health and self-care</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;