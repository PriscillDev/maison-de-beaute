import React, { useState } from 'react';
import { Calendar, Clock, User, Phone, Mail, CreditCard } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

const Booking = () => {
  const { addSubmission } = useFormContext();
  const [formData, setFormData] = useState({
    service: '',
    date: '',
    time: '',
    name: '',
    email: '',
    phone: '',
    notes: ''
  });

  const services = [
    { name: 'Classic Manicure', price: 35, duration: '45 min' },
    { name: 'Gel Manicure', price: 50, duration: '60 min' },
    { name: 'Acrylic Extensions', price: 65, duration: '90 min' },
    { name: 'Classic Pedicure', price: 40, duration: '50 min' },
    { name: 'Spa Pedicure', price: 55, duration: '70 min' },
    { name: 'Classic Facial', price: 75, duration: '60 min' },
    { name: 'Swedish Massage', price: 80, duration: '60 min' },
    { name: 'Bridal Package', price: 200, duration: '4 hours' },
    { name: 'Spa Day Package', price: 180, duration: '3 hours' }
  ];

  const timeSlots = [
    '9:00 AM', '10:00 AM', '11:00 AM', '12:00 PM',
    '1:00 PM', '2:00 PM', '3:00 PM', '4:00 PM',
    '5:00 PM', '6:00 PM'
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSubmission({
      type: 'booking',
      data: formData
    });
    alert('Booking submitted successfully! We will contact you shortly to confirm your appointment.');
    setFormData({
      service: '',
      date: '',
      time: '',
      name: '',
      email: '',
      phone: '',
      notes: ''
    });
  };

  const selectedService = services.find(s => s.name === formData.service);

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Book Your Appointment</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Select your preferred service and schedule your visit to our luxury spa.
          </p>
        </div>
      </section>

      {/* Booking Form */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Service Selection */}
              <div className="md:col-span-2">
                <h2 className="text-2xl font-bold text-deep-teal mb-6">Select Your Service</h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {services.map((service, index) => (
                    <div
                      key={index}
                      className={`p-4 border-2 rounded-xl cursor-pointer transition-all duration-300 ${
                        formData.service === service.name
                          ? 'border-rose-gold bg-rose-gold/10'
                          : 'border-gray-200 hover:border-rose-gold/50'
                      }`}
                      onClick={() => setFormData({ ...formData, service: service.name })}
                    >
                      <h3 className="font-semibold text-deep-teal mb-2">{service.name}</h3>
                      <p className="text-rose-gold font-bold">${service.price}</p>
                      <p className="text-gray-600 text-sm">{service.duration}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Date & Time Selection */}
              <div>
                <h2 className="text-2xl font-bold text-deep-teal mb-6">Select Date & Time</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Calendar className="inline h-4 w-4 mr-2" />
                      Preferred Date
                    </label>
                    <input
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Clock className="inline h-4 w-4 mr-2" />
                      Preferred Time
                    </label>
                    <select
                      name="time"
                      value={formData.time}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    >
                      <option value="">Select time</option>
                      {timeSlots.map((time, index) => (
                        <option key={index} value={time}>{time}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Personal Information */}
              <div>
                <h2 className="text-2xl font-bold text-deep-teal mb-6">Your Information</h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <User className="inline h-4 w-4 mr-2" />
                      Full Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Mail className="inline h-4 w-4 mr-2" />
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      <Phone className="inline h-4 w-4 mr-2" />
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                    />
                  </div>
                </div>
              </div>

              {/* Additional Notes */}
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Additional Notes (Optional)
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                  placeholder="Any special requests or information we should know..."
                />
              </div>
            </div>

            {/* Booking Summary */}
            {selectedService && (
              <div className="bg-gray-50 p-6 rounded-xl">
                <h3 className="text-lg font-semibold text-deep-teal mb-4">Booking Summary</h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <p className="text-gray-600">Service:</p>
                    <p className="font-semibold">{selectedService.name}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Price:</p>
                    <p className="font-semibold text-rose-gold">${selectedService.price}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Duration:</p>
                    <p className="font-semibold">{selectedService.duration}</p>
                  </div>
                  <div>
                    <p className="text-gray-600">Date & Time:</p>
                    <p className="font-semibold">{formData.date} at {formData.time}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <div className="text-center">
              <button
                type="submit"
                className="bg-rose-gold hover:bg-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105"
              >
                <CreditCard className="inline h-5 w-5 mr-2" />
                Confirm Booking
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Booking Info */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Calendar className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Easy Scheduling</h3>
              <p className="text-gray-600">Book online 24/7 or call us during business hours</p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Flexible Hours</h3>
              <p className="text-gray-600">Open Monday-Saturday from 9 AM to 7 PM</p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Phone className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Quick Confirmation</h3>
              <p className="text-gray-600">We'll confirm your appointment within 2 hours</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Booking;