import React, { createContext, useContext, useState, ReactNode } from 'react';

interface FormSubmission {
  id: string;
  type: 'contact' | 'booking' | 'career';
  data: any;
  timestamp: Date;
}

interface FormContextType {
  submissions: FormSubmission[];
  addSubmission: (submission: Omit<FormSubmission, 'id' | 'timestamp'>) => void;
}

const FormContext = createContext<FormContextType | undefined>(undefined);

export const useFormContext = () => {
  const context = useContext(FormContext);
  if (!context) {
    throw new Error('useFormContext must be used within a FormProvider');
  }
  return context;
};

export const FormProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [submissions, setSubmissions] = useState<FormSubmission[]>([]);

  const addSubmission = (submission: Omit<FormSubmission, 'id' | 'timestamp'>) => {
    const newSubmission: FormSubmission = {
      ...submission,
      id: Date.now().toString(),
      timestamp: new Date(),
    };
    setSubmissions(prev => [...prev, newSubmission]);
  };

  return (
    <FormContext.Provider value={{ submissions, addSubmission }}>
      {children}
    </FormContext.Provider>
  );
};