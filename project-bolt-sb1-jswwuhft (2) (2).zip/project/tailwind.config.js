/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'rose-gold': '#E8B4B8',
        'deep-teal': '#2D5A5A',
        'cream': '#F8F5F1',
        'gold': '#D4AF37',
      },
    },
  },
  plugins: [],
};