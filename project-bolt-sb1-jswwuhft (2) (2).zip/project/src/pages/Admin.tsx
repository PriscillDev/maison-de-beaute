import React, { useState } from 'react';
import { useFormContext } from '../context/FormContext';
import { Calendar, User, Phone, Mail, Briefcase, MessageSquare, Eye, Filter } from 'lucide-react';

const Admin = () => {
  const { submissions } = useFormContext();
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);
  const [filterType, setFilterType] = useState<'all' | 'contact' | 'booking' | 'career'>('all');

  const filteredSubmissions = filterType === 'all' 
    ? submissions 
    : submissions.filter(submission => submission.type === filterType);

  const getSubmissionIcon = (type: string) => {
    switch (type) {
      case 'contact':
        return <MessageSquare className="h-5 w-5 text-blue-600" />;
      case 'booking':
        return <Calendar className="h-5 w-5 text-green-600" />;
      case 'career':
        return <Briefcase className="h-5 w-5 text-purple-600" />;
      default:
        return <User className="h-5 w-5 text-gray-600" />;
    }
  };

  const getSubmissionColor = (type: string) => {
    switch (type) {
      case 'contact':
        return 'bg-blue-100 text-blue-800';
      case 'booking':
        return 'bg-green-100 text-green-800';
      case 'career':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const renderSubmissionDetails = (submission: any) => {
    const { type, data } = submission;
    
    switch (type) {
      case 'contact':
        return (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <p className="text-gray-900">{data.name}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <p className="text-gray-900">{data.email}</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <p className="text-gray-900">{data.phone || 'Not provided'}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject</label>
                <p className="text-gray-900">{data.subject || 'Not specified'}</p>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Message</label>
              <p className="text-gray-900 whitespace-pre-wrap">{data.message}</p>
            </div>
          </div>
        );
      
      case 'booking':
        return (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <p className="text-gray-900">{data.name}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <p className="text-gray-900">{data.email}</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <p className="text-gray-900">{data.phone}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Service</label>
                <p className="text-gray-900">{data.service}</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <p className="text-gray-900">{data.date}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                <p className="text-gray-900">{data.time}</p>
              </div>
            </div>
            {data.notes && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                <p className="text-gray-900 whitespace-pre-wrap">{data.notes}</p>
              </div>
            )}
          </div>
        );
      
      case 'career':
        return (
          <div className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <p className="text-gray-900">{data.name}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <p className="text-gray-900">{data.email}</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                <p className="text-gray-900">{data.phone}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Position</label>
                <p className="text-gray-900">{data.position}</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Experience</label>
                <p className="text-gray-900">{data.experience}</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Availability</label>
                <p className="text-gray-900">{data.availability}</p>
              </div>
            </div>
            {data.portfolio && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Portfolio/Resume</label>
                <a href={data.portfolio} target="_blank" rel="noopener noreferrer" className="text-rose-gold hover:text-rose-gold/80">
                  {data.portfolio}
                </a>
              </div>
            )}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Cover Letter</label>
              <p className="text-gray-900 whitespace-pre-wrap">{data.coverLetter}</p>
            </div>
          </div>
        );
      
      default:
        return <p className="text-gray-600">No details available</p>;
    }
  };

  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-deep-teal mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage form submissions and customer inquiries</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center">
              <MessageSquare className="h-8 w-8 text-blue-600 mr-3" />
              <div>
                <p className="text-sm text-gray-600">Contact Forms</p>
                <p className="text-2xl font-bold text-deep-teal">
                  {submissions.filter(s => s.type === 'contact').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center">
              <Calendar className="h-8 w-8 text-green-600 mr-3" />
              <div>
                <p className="text-sm text-gray-600">Bookings</p>
                <p className="text-2xl font-bold text-deep-teal">
                  {submissions.filter(s => s.type === 'booking').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center">
              <Briefcase className="h-8 w-8 text-purple-600 mr-3" />
              <div>
                <p className="text-sm text-gray-600">Job Applications</p>
                <p className="text-2xl font-bold text-deep-teal">
                  {submissions.filter(s => s.type === 'career').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-md">
            <div className="flex items-center">
              <User className="h-8 w-8 text-rose-gold mr-3" />
              <div>
                <p className="text-sm text-gray-600">Total Submissions</p>
                <p className="text-2xl font-bold text-deep-teal">{submissions.length}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filter */}
        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <Filter className="h-5 w-5 text-gray-600" />
            <span className="text-sm font-medium text-gray-700">Filter by type:</span>
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
            >
              <option value="all">All Submissions</option>
              <option value="contact">Contact Forms</option>
              <option value="booking">Bookings</option>
              <option value="career">Job Applications</option>
            </select>
          </div>
        </div>

        {/* Submissions List */}
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-deep-teal">Submissions</h2>
              </div>
              <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
                {filteredSubmissions.length === 0 ? (
                  <div className="p-6 text-center text-gray-500">
                    No submissions found
                  </div>
                ) : (
                  filteredSubmissions.map((submission) => (
                    <div
                      key={submission.id}
                      className={`p-4 cursor-pointer hover:bg-gray-50 ${
                        selectedSubmission?.id === submission.id ? 'bg-rose-gold/10' : ''
                      }`}
                      onClick={() => setSelectedSubmission(submission)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center space-x-3">
                          {getSubmissionIcon(submission.type)}
                          <div>
                            <p className="font-medium text-deep-teal">
                              {submission.data.name}
                            </p>
                            <p className="text-sm text-gray-600">
                              {submission.data.email}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getSubmissionColor(submission.type)}`}>
                            {submission.type}
                          </span>
                          <p className="text-xs text-gray-500 mt-1">
                            {formatDate(submission.timestamp)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Submission Details */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-deep-teal">Details</h2>
              </div>
              <div className="p-6">
                {selectedSubmission ? (
                  <div>
                    <div className="flex items-center space-x-3 mb-4">
                      {getSubmissionIcon(selectedSubmission.type)}
                      <div>
                        <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${getSubmissionColor(selectedSubmission.type)}`}>
                          {selectedSubmission.type}
                        </span>
                        <p className="text-xs text-gray-500 mt-1">
                          {formatDate(selectedSubmission.timestamp)}
                        </p>
                      </div>
                    </div>
                    {renderSubmissionDetails(selectedSubmission)}
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <Eye className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <p>Select a submission to view details</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;