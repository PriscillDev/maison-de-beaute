import React from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      name: "Sarah Mitchell",
      service: "Gel Manicure & Pedicure",
      rating: 5,
      text: "Absolutely amazing service! The staff is incredibly skilled and the atmosphere is so relaxing. I've been coming here for over a year and they never disappoint.",
      image: "https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Emily Chen",
      service: "Facial Treatment",
      rating: 5,
      text: "The best facial I've ever had! My skin has never looked better. The products they use are top quality and the results are incredible.",
      image: "https://images.pexels.com/photos/3762801/pexels-photo-3762801.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Jessica Rodriguez",
      service: "Nail Art & Extensions",
      rating: 5,
      text: "Maria is an absolute artist! She created the most beautiful nail design I've ever had. The attention to detail is phenomenal.",
      image: "https://images.pexels.com/photos/3762802/pexels-photo-3762802.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Ashley Taylor",
      service: "Spa Day Package",
      rating: 5,
      text: "Treated myself to the spa day package and it was worth every penny! So relaxing and rejuvenating. I left feeling like a new person.",
      image: "https://images.pexels.com/photos/3762803/pexels-photo-3762803.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Amanda Johnson",
      service: "Massage Therapy",
      rating: 5,
      text: "Emma's massage therapy is incredible! She really knows how to work out all the tension and stress. I feel so much better after each session.",
      image: "https://images.pexels.com/photos/3762804/pexels-photo-3762804.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Lisa Wang",
      service: "Bridal Package",
      rating: 5,
      text: "They made my wedding day perfect! The bridal package was everything I dreamed of. Professional, beautiful, and stress-free.",
      image: "https://images.pexels.com/photos/3762805/pexels-photo-3762805.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Rachel Green",
      service: "Acrylic Nails",
      rating: 5,
      text: "Best acrylic nails in town! They last so long and always look perfect. The staff is friendly and professional.",
      image: "https://images.pexels.com/photos/3762806/pexels-photo-3762806.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Stephanie Davis",
      service: "Pedicure",
      rating: 5,
      text: "Such a relaxing and thorough pedicure! My feet have never felt so smooth and looked so beautiful. Will definitely be back!",
      image: "https://images.pexels.com/photos/3762807/pexels-photo-3762807.jpeg?auto=compress&cs=tinysrgb&w=200"
    },
    {
      name: "Nicole Brown",
      service: "Anti-Aging Facial",
      rating: 5,
      text: "The anti-aging facial is amazing! I can see visible results and my skin feels so much firmer and smoother.",
      image: "https://images.pexels.com/photos/3762808/pexels-photo-3762808.jpeg?auto=compress&cs=tinysrgb&w=200"
    }
  ];

  const stats = [
    { number: "5,000+", label: "Happy Clients" },
    { number: "4.9/5", label: "Average Rating" },
    { number: "98%", label: "Would Recommend" },
    { number: "95%", label: "Return Rate" }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">What Our Clients Say</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Read reviews from our satisfied customers and see why they choose Luxe Spa for their beauty needs.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-deep-teal mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Grid */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Client Reviews</h2>
            <p className="text-gray-600 text-lg">Hear from our amazing clients about their experiences</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h3 className="font-semibold text-deep-teal">{testimonial.name}</h3>
                    <p className="text-sm text-gray-600">{testimonial.service}</p>
                  </div>
                </div>
                
                <div className="flex mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-rose-gold fill-current" />
                  ))}
                </div>
                
                <div className="relative">
                  <Quote className="absolute top-0 left-0 h-6 w-6 text-rose-gold/20 -translate-x-1 -translate-y-1" />
                  <p className="text-gray-600 italic pl-4">{testimonial.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Review Highlights */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">What Makes Us Special</h2>
            <p className="text-gray-600 text-lg">Common themes from our client reviews</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Exceptional Quality</h3>
              <p className="text-gray-600">Clients consistently praise our attention to detail and high-quality results</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Professional Staff</h3>
              <p className="text-gray-600">Our skilled team members are frequently mentioned for their expertise and friendliness</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Relaxing Environment</h3>
              <p className="text-gray-600">Customers love our peaceful atmosphere and luxurious spa setting</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Long-lasting Results</h3>
              <p className="text-gray-600">Clients are impressed with how long their treatments last and maintain their beauty</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Hygienic Practices</h3>
              <p className="text-gray-600">Safety and cleanliness are top priorities, earning client trust and confidence</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Value for Money</h3>
              <p className="text-gray-600">Clients feel they receive excellent value for the quality of services provided</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Review */}
      <section className="py-16 bg-gradient-to-r from-rose-gold/10 to-deep-teal/10">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Quote className="h-12 w-12 text-rose-gold mx-auto mb-6" />
          <blockquote className="text-2xl sm:text-3xl text-deep-teal font-medium mb-6 italic">
            "I've been to many spas, but Luxe Spa is in a league of its own. The level of service, attention to detail, and overall experience is unmatched. It's my go-to place for all my beauty needs."
          </blockquote>
          <div className="flex items-center justify-center">
            <img
              src="https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=100"
              alt="Featured client"
              className="w-16 h-16 rounded-full object-cover mr-4"
            />
            <div>
              <p className="font-semibold text-deep-teal">Sarah Johnson</p>
              <p className="text-gray-600">VIP Client since 2020</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-deep-teal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to Experience Luxury?</h2>
          <p className="text-xl text-white/90 mb-8">Join thousands of satisfied customers who trust us with their beauty needs</p>
          <button className="bg-rose-gold hover:bg-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
            Book Your Appointment
          </button>
        </div>
      </section>
    </div>
  );
};

export default Testimonials;