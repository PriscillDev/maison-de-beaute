import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const galleryImages = [
    {
      src: "https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Classic Manicure",
      category: "Manicure"
    },
    {
      src: "https://images.pexels.com/photos/3997992/pexels-photo-3997992.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Spa Pedicure",
      category: "Pedicure"
    },
    {
      src: "https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Gel Extensions",
      category: "Nail Art"
    },
    {
      src: "https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Facial Treatment",
      category: "Facial"
    },
    {
      src: "https://images.pexels.com/photos/3997995/pexels-photo-3997995.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Massage Therapy",
      category: "Massage"
    },
    {
      src: "https://images.pexels.com/photos/3997996/pexels-photo-3997996.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Nail Art Design",
      category: "Nail Art"
    },
    {
      src: "https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Spa Environment",
      category: "Spa"
    },
    {
      src: "https://images.pexels.com/photos/3762801/pexels-photo-3762801.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Relaxation Area",
      category: "Spa"
    },
    {
      src: "https://images.pexels.com/photos/3762802/pexels-photo-3762802.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Treatment Room",
      category: "Spa"
    },
    {
      src: "https://images.pexels.com/photos/3762803/pexels-photo-3762803.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Acrylic Nails",
      category: "Nail Art"
    },
    {
      src: "https://images.pexels.com/photos/3762804/pexels-photo-3762804.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "French Manicure",
      category: "Manicure"
    },
    {
      src: "https://images.pexels.com/photos/3762805/pexels-photo-3762805.jpeg?auto=compress&cs=tinysrgb&w=600",
      title: "Pedicure Station",
      category: "Pedicure"
    }
  ];

  const beforeAfterImages = [
    {
      before: "https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=400",
      after: "https://images.pexels.com/photos/3997992/pexels-photo-3997992.jpeg?auto=compress&cs=tinysrgb&w=400",
      title: "Nail Transformation",
      description: "Complete nail makeover with gel extensions and art"
    },
    {
      before: "https://images.pexels.com/photos/3997993/pexels-photo-3997993.jpeg?auto=compress&cs=tinysrgb&w=400",
      after: "https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=400",
      title: "Facial Results",
      description: "Skin rejuvenation after our signature facial treatment"
    },
    {
      before: "https://images.pexels.com/photos/3997995/pexels-photo-3997995.jpeg?auto=compress&cs=tinysrgb&w=400",
      after: "https://images.pexels.com/photos/3997996/pexels-photo-3997996.jpeg?auto=compress&cs=tinysrgb&w=400",
      title: "Pedicure Transformation",
      description: "Professional pedicure with callus removal and polish"
    }
  ];

  const categories = ["All", "Manicure", "Pedicure", "Nail Art", "Facial", "Massage", "Spa"];
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filteredImages = selectedCategory === "All" 
    ? galleryImages 
    : galleryImages.filter(img => img.category === selectedCategory);

  const openModal = (index: number) => {
    setSelectedImage(index);
  };

  const closeModal = () => {
    setSelectedImage(null);
  };

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % filteredImages.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage(selectedImage === 0 ? filteredImages.length - 1 : selectedImage - 1);
    }
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Our Gallery</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Explore our beautiful work and see the transformations we create for our clients.
          </p>
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Before & After</h2>
            <p className="text-gray-600 text-lg">See the amazing transformations we achieve</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {beforeAfterImages.map((transformation, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl overflow-hidden shadow-lg">
                <div className="grid grid-cols-2">
                  <div className="relative">
                    <img
                      src={transformation.before}
                      alt="Before"
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 left-2 bg-gray-800 text-white px-2 py-1 rounded text-xs">
                      BEFORE
                    </div>
                  </div>
                  <div className="relative">
                    <img
                      src={transformation.after}
                      alt="After"
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 right-2 bg-rose-gold text-white px-2 py-1 rounded text-xs">
                      AFTER
                    </div>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-deep-teal mb-2">{transformation.title}</h3>
                  <p className="text-gray-600">{transformation.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Main Gallery */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Our Work</h2>
            <p className="text-gray-600 text-lg">Browse through our portfolio of beautiful treatments</p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  selectedCategory === category
                    ? 'bg-rose-gold text-white shadow-lg'
                    : 'bg-white text-deep-teal hover:bg-rose-gold/10 border border-gray-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Image Grid */}
          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredImages.map((image, index) => (
              <div
                key={index}
                className="group cursor-pointer overflow-hidden rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={() => openModal(index)}
              >
                <div className="relative overflow-hidden">
                  <img
                    src={image.src}
                    alt={image.title}
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-4 left-4 text-white">
                      <h3 className="text-lg font-semibold">{image.title}</h3>
                      <p className="text-sm text-rose-gold">{image.category}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Modal */}
      {selectedImage !== null && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={closeModal}
              className="absolute top-4 right-4 text-white hover:text-rose-gold transition-colors z-10"
            >
              <X className="h-8 w-8" />
            </button>
            
            <button
              onClick={prevImage}
              className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white hover:text-rose-gold transition-colors z-10"
            >
              <ChevronLeft className="h-12 w-12" />
            </button>
            
            <button
              onClick={nextImage}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-white hover:text-rose-gold transition-colors z-10"
            >
              <ChevronRight className="h-12 w-12" />
            </button>
            
            <img
              src={filteredImages[selectedImage].src}
              alt={filteredImages[selectedImage].title}
              className="max-w-full max-h-full object-contain"
            />
            
            <div className="absolute bottom-4 left-4 text-white">
              <h3 className="text-xl font-semibold">{filteredImages[selectedImage].title}</h3>
              <p className="text-rose-gold">{filteredImages[selectedImage].category}</p>
            </div>
          </div>
        </div>
      )}

      {/* CTA Section */}
      <section className="py-16 bg-deep-teal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready for Your Transformation?</h2>
          <p className="text-xl text-white/90 mb-8">Book your appointment and let us create something beautiful for you</p>
          <button className="bg-rose-gold hover:bg-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
            Book Your Appointment
          </button>
        </div>
      </section>
    </div>
  );
};

export default Gallery;