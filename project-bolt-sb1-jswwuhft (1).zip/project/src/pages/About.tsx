import React from 'react';
import { Award, Users, Heart, Clock } from 'lucide-react';

const About = () => {
  const stats = [
    { number: "5,000+", label: "Happy Clients" },
    { number: "10+", label: "Years Experience" },
    { number: "15+", label: "Expert Staff" },
    { number: "50+", label: "Services Offered" }
  ];

  const team = [
    {
      name: "Sarah Johnson",
      role: "Founder & Lead Aesthetician",
      image: "https://images.pexels.com/photos/3762800/pexels-photo-3762800.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "With over 15 years of experience in the beauty industry, Sarah founded Luxe Spa to provide exceptional nail care and beauty services."
    },
    {
      name: "Maria Rodriguez",
      role: "Senior Nail Technician",
      image: "https://images.pexels.com/photos/3762801/pexels-photo-3762801.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Maria specializes in nail art and extensions, bringing creativity and precision to every client's experience."
    },
    {
      name: "Emma Chen",
      role: "Licensed Massage Therapist",
      image: "https://images.pexels.com/photos/3762802/pexels-photo-3762802.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Emma's expertise in therapeutic massage and relaxation techniques helps clients achieve total wellness."
    },
    {
      name: "Jessica Williams",
      role: "Skincare Specialist",
      image: "https://images.pexels.com/photos/3762803/pexels-photo-3762803.jpeg?auto=compress&cs=tinysrgb&w=400",
      bio: "Jessica's passion for skincare and facial treatments ensures every client leaves with glowing, healthy skin."
    }
  ];

  const values = [
    {
      icon: <Award className="h-8 w-8 text-rose-gold" />,
      title: "Excellence",
      description: "We strive for perfection in every service we provide"
    },
    {
      icon: <Users className="h-8 w-8 text-rose-gold" />,
      title: "Client-Focused",
      description: "Your comfort and satisfaction are our top priorities"
    },
    {
      icon: <Heart className="h-8 w-8 text-rose-gold" />,
      title: "Passion",
      description: "We love what we do and it shows in our work"
    },
    {
      icon: <Clock className="h-8 w-8 text-rose-gold" />,
      title: "Reliability",
      description: "Consistent quality and punctual service, every time"
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">About Maison de Beauté</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Since 2014, we have been dedicated to providing exceptional beauty and wellness services in a luxurious and relaxing environment.
          </p>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl font-bold text-deep-teal mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Story Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-6">Our Story</h2>
              <p className="text-gray-600 text-lg mb-6">
                Maison de Beauté was born from a simple vision: to create a sanctuary where beauty meets wellness, and where every client feels pampered and rejuvenated. What started as a small nail salon has evolved into a full-service spa offering comprehensive beauty and wellness treatments.
              </p>
              <p className="text-gray-600 text-lg mb-6">
                Our founder, Sarah Johnson, recognized the need for a premium spa experience that combines expert techniques with luxurious amenities. Today, we continue to uphold those same values of excellence, innovation, and personalized care.
              </p>
              <p className="text-gray-600 text-lg">
                We use only the finest products and latest techniques, ensuring that every visit to Maison de Beauté is a memorable experience that leaves you looking beautiful, feeling confident, and completely relaxed.
              </p>
            </div>
            <div className="lg:order-first">
              <img
                src="https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Our spa interior"
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Our Values</h2>
            <p className="text-gray-600 text-lg">The principles that guide everything we do</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center">
                <div className="bg-rose-gold/10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  {value.icon}
                </div>
                <h3 className="text-xl font-semibold text-deep-teal mb-2">{value.title}</h3>
                <p className="text-gray-600">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Meet Our Team</h2>
            <p className="text-gray-600 text-lg">Our passionate and skilled professionals</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-64 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-deep-teal mb-1">{member.name}</h3>
                  <p className="text-rose-gold font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Certifications & Awards</h2>
            <p className="text-gray-600 text-lg">Recognized for our excellence and commitment to quality</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">State Licensed</h3>
              <p className="text-gray-600">All our technicians are fully licensed and certified</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Best Spa 2023</h3>
              <p className="text-gray-600">Winner of the Local Business Excellence Award</p>
            </div>
            
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                <Award className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Health & Safety</h3>
              <p className="text-gray-600">Certified in sanitation and safety protocols</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;