import React from 'react';
import { Clock, Star, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Services = () => {
  const serviceCategories = [
    {
      title: "Manicure Services",
      description: "Professional nail care and art",
      image: "https://images.pexels.com/photos/3997991/pexels-photo-3997991.jpeg?auto=compress&cs=tinysrgb&w=600",
      services: [
        { name: "Classic Manicure", price: "$35", duration: "45 min", description: "Traditional nail care with cuticle treatment and polish" },
        { name: "Gel Manicure", price: "$50", duration: "60 min", description: "Long-lasting gel polish with base and top coat" },
        { name: "Acrylic Extensions", price: "$65", duration: "90 min", description: "Custom length and shape with your choice of finish" },
        { name: "Nail Art Design", price: "$15-45", duration: "30-60 min", description: "Creative designs from simple to intricate patterns" }
      ]
    },
    {
      title: "Pedicure Services",
      description: "Relaxing foot care treatments",
      image: "https://images.pexels.com/photos/3997992/pexels-photo-3997992.jpeg?auto=compress&cs=tinysrgb&w=600",
      services: [
        { name: "Classic Pedicure", price: "$40", duration: "50 min", description: "Essential foot care with nail trimming and polish" },
        { name: "Spa Pedicure", price: "$55", duration: "70 min", description: "Luxurious treatment with foot soak and massage" },
        { name: "Paraffin Pedicure", price: "$65", duration: "80 min", description: "Moisturizing paraffin treatment for soft, smooth feet" },
        { name: "Medical Pedicure", price: "$70", duration: "60 min", description: "Therapeutic treatment for foot health issues" }
      ]
    },
    {
      title: "Beauty Treatments",
      description: "Facial and body wellness services",
      image: "https://images.pexels.com/photos/3997994/pexels-photo-3997994.jpeg?auto=compress&cs=tinysrgb&w=600",
      services: [
        { name: "Classic Facial", price: "$75", duration: "60 min", description: "Deep cleansing and hydrating facial treatment" },
        { name: "Anti-Aging Facial", price: "$95", duration: "75 min", description: "Advanced treatment targeting fine lines and wrinkles" },
        { name: "Hydrating Facial", price: "$85", duration: "60 min", description: "Intensive moisture treatment for dry skin" },
        { name: "Acne Treatment", price: "$90", duration: "70 min", description: "Specialized care for problem skin" }
      ]
    },
    {
      title: "Massage & Wellness",
      description: "Relaxation and therapeutic treatments",
      image: "https://images.pexels.com/photos/3997995/pexels-photo-3997995.jpeg?auto=compress&cs=tinysrgb&w=600",
      services: [
        { name: "Swedish Massage", price: "$80", duration: "60 min", description: "Relaxing full-body massage for stress relief" },
        { name: "Deep Tissue Massage", price: "$90", duration: "60 min", description: "Therapeutic massage for muscle tension" },
        { name: "Hot Stone Massage", price: "$100", duration: "75 min", description: "Soothing heated stones for deep relaxation" },
        { name: "Aromatherapy Massage", price: "$85", duration: "60 min", description: "Essential oil massage for mind and body wellness" }
      ]
    },
    {
      title: "Waxing Services",
      description: "Professional hair removal",
      image: "https://images.pexels.com/photos/3997996/pexels-photo-3997996.jpeg?auto=compress&cs=tinysrgb&w=600",
      services: [
        { name: "Eyebrow Wax", price: "$25", duration: "20 min", description: "Professional eyebrow shaping and styling" },
        { name: "Full Leg Wax", price: "$65", duration: "60 min", description: "Complete leg hair removal service" },
        { name: "Bikini Wax", price: "$45", duration: "30 min", description: "Professional bikini area hair removal" },
        { name: "Upper Lip Wax", price: "$15", duration: "15 min", description: "Quick and gentle upper lip hair removal" }
      ]
    }
  ];

  const packages = [
    {
      name: "Bridal Package",
      price: "$200",
      duration: "4 hours",
      description: "Complete bridal preparation including manicure, pedicure, facial, and makeup",
      services: ["Gel Manicure", "Spa Pedicure", "Hydrating Facial", "Bridal Makeup"]
    },
    {
      name: "Spa Day Package",
      price: "$180",
      duration: "3 hours",
      description: "Ultimate relaxation experience with multiple treatments",
      services: ["Swedish Massage", "Classic Facial", "Classic Pedicure", "Aromatherapy"]
    },
    {
      name: "Girls' Day Out",
      price: "$150",
      duration: "2.5 hours",
      description: "Perfect for groups wanting to relax together",
      services: ["Gel Manicure", "Mini Facial", "Champagne & Treats", "Group Discount"]
    }
  ];

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Our Services</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Discover our comprehensive range of beauty and wellness treatments designed to help you look and feel your best.
          </p>
        </div>
      </section>

      {/* Services Categories */}
      {serviceCategories.map((category, categoryIndex) => (
        <section key={categoryIndex} className={`py-16 ${categoryIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center mb-12">
              <div className={categoryIndex % 2 === 1 ? 'lg:order-2' : ''}>
                <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">{category.title}</h2>
                <p className="text-gray-600 text-lg mb-6">{category.description}</p>
                <img
                  src={category.image}
                  alt={category.title}
                  className="rounded-2xl shadow-xl"
                />
              </div>
              <div className={categoryIndex % 2 === 1 ? 'lg:order-1' : ''}>
                <div className="grid gap-6">
                  {category.services.map((service, serviceIndex) => (
                    <div key={serviceIndex} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                      <div className="flex justify-between items-start mb-3">
                        <h3 className="text-xl font-semibold text-deep-teal">{service.name}</h3>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-rose-gold">{service.price}</div>
                          <div className="flex items-center text-gray-500 text-sm">
                            <Clock className="h-4 w-4 mr-1" />
                            {service.duration}
                          </div>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">{service.description}</p>
                      <Link
                        to="/booking"
                        className="inline-flex items-center text-rose-gold hover:text-rose-gold/80 font-semibold"
                      >
                        Book Now <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      ))}

      {/* Packages Section */}
      <section className="py-16 bg-gradient-to-r from-rose-gold/10 to-deep-teal/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Special Packages</h2>
            <p className="text-gray-600 text-lg">Save more with our carefully curated service bundles</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {packages.map((pkg, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-shadow duration-300">
                <div className="bg-gradient-to-r from-deep-teal to-rose-gold p-6">
                  <h3 className="text-2xl font-bold text-white mb-2">{pkg.name}</h3>
                  <div className="flex items-center text-white/90">
                    <Clock className="h-4 w-4 mr-2" />
                    {pkg.duration}
                  </div>
                </div>
                <div className="p-6">
                  <div className="text-3xl font-bold text-deep-teal mb-4">{pkg.price}</div>
                  <p className="text-gray-600 mb-6">{pkg.description}</p>
                  <div className="space-y-2 mb-6">
                    {pkg.services.map((service, serviceIndex) => (
                      <div key={serviceIndex} className="flex items-center text-sm text-gray-600">
                        <Star className="h-4 w-4 text-rose-gold mr-2" />
                        {service}
                      </div>
                    ))}
                  </div>
                  <Link
                    to="/booking"
                    className="w-full bg-rose-gold hover:bg-rose-gold/90 text-white py-3 px-6 rounded-full font-semibold transition-colors duration-300 inline-block text-center"
                  >
                    Book Package
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-deep-teal">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Ready to Book Your Service?</h2>
          <p className="text-xl text-white/90 mb-8">Choose from our wide range of services and packages</p>
          <Link
            to="/booking"
            className="bg-rose-gold hover:bg-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105"
          >
            Book Your Appointment
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;