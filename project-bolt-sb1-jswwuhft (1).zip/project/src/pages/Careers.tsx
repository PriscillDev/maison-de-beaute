import React, { useState } from 'react';
import { Briefcase, Clock, MapPin, Users, Star, Upload } from 'lucide-react';
import { useFormContext } from '../context/FormContext';

const Careers = () => {
  const { addSubmission } = useFormContext();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    position: '',
    experience: '',
    portfolio: '',
    availability: '',
    coverLetter: ''
  });

  const positions = [
    {
      title: "Senior Nail Technician",
      type: "Full-time",
      location: "Luxe Spa - Main Location",
      salary: "$45,000 - $60,000",
      description: "We're looking for an experienced nail technician to join our team. Must have 3+ years experience and be licensed.",
      requirements: [
        "Valid nail technician license",
        "3+ years of experience",
        "Knowledge of gel, acrylic, and nail art",
        "Excellent customer service skills",
        "Ability to work in a fast-paced environment"
      ]
    },
    {
      title: "Licensed Massage Therapist",
      type: "Part-time",
      location: "Luxe Spa - Main Location",
      salary: "$25 - $35 per hour",
      description: "Join our wellness team as a licensed massage therapist. Experience with various massage techniques preferred.",
      requirements: [
        "Licensed massage therapist",
        "Experience with Swedish, deep tissue massage",
        "Professional demeanor",
        "Flexible schedule",
        "Team player attitude"
      ]
    },
    {
      title: "Spa Receptionist",
      type: "Full-time",
      location: "Luxe Spa - Main Location",
      salary: "$30,000 - $35,000",
      description: "Front desk position managing appointments, customer service, and administrative tasks.",
      requirements: [
        "High school diploma or equivalent",
        "Excellent communication skills",
        "Experience with booking systems",
        "Multi-tasking abilities",
        "Professional appearance"
      ]
    },
    {
      title: "Skincare Specialist",
      type: "Full-time",
      location: "Luxe Spa - Main Location",
      salary: "$40,000 - $55,000",
      description: "Provide facial treatments and skincare consultations. Esthetician license required.",
      requirements: [
        "Licensed esthetician",
        "2+ years experience",
        "Knowledge of skincare products",
        "Sales experience preferred",
        "Passion for skincare"
      ]
    }
  ];

  const experienceOptions = [
    "Less than 1 year",
    "1-2 years",
    "3-5 years",
    "5-10 years",
    "More than 10 years"
  ];

  const availabilityOptions = [
    "Full-time",
    "Part-time",
    "Weekends only",
    "Flexible schedule",
    "Contract work"
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addSubmission({
      type: 'career',
      data: formData
    });
    alert('Application submitted successfully! We will review your application and get back to you soon.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      position: '',
      experience: '',
      portfolio: '',
      availability: '',
      coverLetter: ''
    });
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-deep-teal to-rose-gold">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">Join Our Team</h1>
          <p className="text-xl text-white/90 max-w-3xl mx-auto">
            Be part of a passionate team dedicated to providing exceptional beauty and wellness services.
          </p>
        </div>
      </section>

      {/* Why Work With Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Why Work With Us?</h2>
            <p className="text-gray-600 text-lg">Join a team that values growth, creativity, and excellence</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Competitive Pay</h3>
              <p className="text-gray-600">Attractive salary packages with performance bonuses</p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Great Team</h3>
              <p className="text-gray-600">Work with passionate professionals in a supportive environment</p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Briefcase className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Career Growth</h3>
              <p className="text-gray-600">Opportunities for advancement and professional development</p>
            </div>
            <div className="text-center">
              <div className="bg-rose-gold/10 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-rose-gold" />
              </div>
              <h3 className="text-xl font-semibold text-deep-teal mb-2">Work-Life Balance</h3>
              <p className="text-gray-600">Flexible scheduling and time off when you need it</p>
            </div>
          </div>
        </div>
      </section>

      {/* Open Positions */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Open Positions</h2>
            <p className="text-gray-600 text-lg">Explore our current job opportunities</p>
          </div>
          
          <div className="grid lg:grid-cols-2 gap-8">
            {positions.map((position, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 hover:shadow-xl transition-shadow duration-300">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-2xl font-semibold text-deep-teal">{position.title}</h3>
                  <span className="bg-rose-gold/10 text-rose-gold px-3 py-1 rounded-full text-sm font-medium">
                    {position.type}
                  </span>
                </div>
                
                <div className="space-y-2 mb-4">
                  <div className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-2" />
                    {position.location}
                  </div>
                  <div className="flex items-center text-gray-600">
                    <Briefcase className="h-4 w-4 mr-2" />
                    {position.salary}
                  </div>
                </div>
                
                <p className="text-gray-600 mb-4">{position.description}</p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-deep-teal mb-2">Requirements:</h4>
                  <ul className="text-gray-600 text-sm space-y-1">
                    {position.requirements.map((req, reqIndex) => (
                      <li key={reqIndex} className="flex items-center">
                        <Star className="h-3 w-3 text-rose-gold mr-2" />
                        {req}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <button
                  onClick={() => setFormData({ ...formData, position: position.title })}
                  className="w-full bg-rose-gold hover:bg-rose-gold/90 text-white py-3 px-6 rounded-lg font-semibold transition-colors duration-300"
                >
                  Apply Now
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Apply Today</h2>
            <p className="text-gray-600 text-lg">Fill out the form below to submit your application</p>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name *
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Email Address *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                />
              </div>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number *
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Position Applied For *
                </label>
                <select
                  name="position"
                  value={formData.position}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                >
                  <option value="">Select position</option>
                  {positions.map((position, index) => (
                    <option key={index} value={position.title}>{position.title}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div className="grid sm:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Years of Experience *
                </label>
                <select
                  name="experience"
                  value={formData.experience}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                >
                  <option value="">Select experience</option>
                  {experienceOptions.map((exp, index) => (
                    <option key={index} value={exp}>{exp}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Availability *
                </label>
                <select
                  name="availability"
                  value={formData.availability}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                >
                  <option value="">Select availability</option>
                  {availabilityOptions.map((avail, index) => (
                    <option key={index} value={avail}>{avail}</option>
                  ))}
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Portfolio/Resume URL
              </label>
              <input
                type="url"
                name="portfolio"
                value={formData.portfolio}
                onChange={handleChange}
                placeholder="https://your-portfolio.com or resume link"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Cover Letter / Why do you want to work with us? *
              </label>
              <textarea
                name="coverLetter"
                value={formData.coverLetter}
                onChange={handleChange}
                required
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-rose-gold focus:border-rose-gold"
                placeholder="Tell us about yourself and why you'd be a great fit for our team..."
              />
            </div>
            
            <div className="text-center">
              <button
                type="submit"
                className="bg-rose-gold hover:bg-rose-gold/90 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105"
              >
                <Upload className="inline h-5 w-5 mr-2" />
                Submit Application
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-deep-teal mb-4">Employee Benefits</h2>
            <p className="text-gray-600 text-lg">We take care of our team members</p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Health Benefits</h3>
              <p className="text-gray-600">Comprehensive health insurance coverage for full-time employees</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Paid Time Off</h3>
              <p className="text-gray-600">Generous vacation and sick leave policies</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Professional Development</h3>
              <p className="text-gray-600">Training opportunities and conference attendance</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Staff Discounts</h3>
              <p className="text-gray-600">Discounted services and products for employees</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Performance Bonuses</h3>
              <p className="text-gray-600">Quarterly bonuses based on performance and client satisfaction</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <h3 className="text-lg font-semibold text-deep-teal mb-2">Team Events</h3>
              <p className="text-gray-600">Regular team building activities and celebrations</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Careers;